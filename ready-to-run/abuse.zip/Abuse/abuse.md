## Notes
<br/>

Thanks to Jonathan Clark, Dave Taylor and the rest of the Crack Dot Com team for making this 2D game and releasing it as public domain.  Thanks to [Xenoveritas](https://github.com/Xenoveritas/abuse) for porting it so that it's easier to build.  Also thanks to [romadu](https://github.com/romadu/abuse) for the porting work for portmaster.
<br/>

