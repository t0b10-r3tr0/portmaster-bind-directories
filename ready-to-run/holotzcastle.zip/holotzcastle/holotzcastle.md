## Notes
Thanks to [Juan Carlos Seijo Pérez](http://www.mainreactor.net/en/index_en.html) for creating this game and making it available for free!

## Controls

| Button | Action |
|--|--| 
|DPAD| Move|
|A | Jump|


## Compile

```shell
dget -u http://deb.debian.org/debian/pool/main/h/holotz-castle/holotz-castle_1.3.14-12.dsc
cd holotz-castle-1.3.14
modify paths in Makefile to ./
make
```

