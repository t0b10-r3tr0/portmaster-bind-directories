GORANS HIGHRES LANDSCAPES PLUGIN 1.0



Installation:

-drop the zipped file, or the folder, in Aleph One's Plugin directory located:

Aleph One/Prefs/User/Plugins/

If no such directory exists, create one.

When you start Alephone, there will be a plugin menu at the in-game preferences, where you can turn plugins on and off. If the PLugin doesn't show up here, then it has not been installed properly. Should that happen, make sure the file path is correct (remember capital letters!).





What is this:

This is a high resolution landscape plugin for Marathon Infinity. It replaces all landscapes with 2048x1080 versions.





Some notes:

Space Landscape:
The big planet is Lh'owon. The two small planets around it are its moons. The red and blue nebulas are traces of the Nar's planets, which Pfhor have blown to stardust with the Trih Xim.

Moon Landscape:
The view is from Lh'owons second moon Y'loa. The planet rising upon the horizon is Lh'owon. The green little planet is one of Lh'owon's moons. The spaceship, is T'fears battleship from battle group seven. This landscape is not used in Infinity and is likely a leftover from Marathon 2.

Lh'owon Day Landscape
The original 2D image has been replaced with more life like mountains and sand dunes. Stars have also been applied to the atmosphere to show it's much thinner than earth's.

Lh'owon Night Landscape
A darker version of the Lh'owon Day. Lh'owon's two moons are visible. In the original the moons are not visible, but it made more sense to me to make them visible. After all, there's one day out of 28 when the moon is absolutely dark on Earth. If similar conditions exist on Lh'owon, it's more probable the moons are visible than hidden.





Version notes:

1.0 First release





Credits:

3D spaceship in moon landscape - Cryos
Source images - cgtextures.com
Composition and creation of all landscapes - Goran





Input, advice, complaints, and praise:

goransvensson@yahoo.com

http://www.pfhorums.com/index.php?showtopic=5741







