ABOUT:

I created these textures to be faithful to the original low res textures.
My hope is that you'll come to enjoy them just as much as I have.

-Goran 

--------------------------------------------------------------------

INSTALLATION:

STEP 1

Drop the folder "High Res Water Plugin" in your Plugins directory.
If you don't have a Plugins folder you'll have to create one.


Example Search Path:
Aleph One/Prefs/User/Plugins/High Res Water Plugin

STEP 2

Start up Aleph One. In preferences under environment there's a plugin
button. Click on it and enable the plugin.
--------------------------------------------------------------------

CREDITS:

Original Textures - Bungie
Highres Textures - Goran Svensson 

Texture details, such as cracks and marble patterns, were gotten
from cgtextures.com. I take no credit for these patterns. They belong
to cgtextures.com and were used along the specified user agreement on
their website:

http://cgtextures.com/content.php?action=license

----------------------------------------------------------------------

Version notes:

1.0 First release

----------------------------------------------------------------------

Email: goransvensson@gmail.com

