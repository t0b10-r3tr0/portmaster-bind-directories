## Notes

Notes: Thanks to the [Aleph-One-Marathon Team](https://github.com/Aleph-One-Marathon/alephone) for creating this opensource engine. 


## Compile

```shell
Download Sourcetarball from https://alephone.lhowon.org/download/source.php
./configure --without-speex --without-curl --without-zzip --without-png --without-miniupnpc --without-ffmpeg --without-alsa
make
strip Source_Files/alephone
```
