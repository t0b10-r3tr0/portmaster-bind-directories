INFO:

The font used for '+rON' at the startup screen is from the videogame
'Omikron: the Nomad Soul' by Quantic Dreams, published by Eidos.
Truetype file downloaded at http://www.quanticdream.com/french/the_nomad_soul/5_download/download.htm

The 3D models were made with Kinetix 3DSMax3.1
The .ase modelization file is an ASCII exportation from 3DSMax.

The textures and pictures have been created with Adobe Photoshop5.0,
they are based on pictures of the movie and from the work of the guys who sweated to do it.
The textures are .png file format (Mr. Moos' marvelous idea) that you can easily modify
with any picture software dealing with alpha channels.


LEGAL:

All original artwork, models and files by Fabrice Holb�.

No reproduction or re-use of these elements for commercial purposes permitted.
The pictures files can be used and modified only for non-commercial purposes.

The Tron pictures must be taken as fan art and it's not intended
any commercial action or profit on the making and/or exhibition of this artwork.

Any mistake in the credits of any work is unintentional and must be informed to the Authors.
The pictures and scans from Tron� and the films, novels, associated elements and logos,
and other licensed works based upon it are copyright � Walt Disney Productions.

No copyright infringement in this game is intended.

No claim of ownership nor reassignment of Walt Disney Productions' copyright and copyrighted
material to any other parties is intended or inferred by this game.