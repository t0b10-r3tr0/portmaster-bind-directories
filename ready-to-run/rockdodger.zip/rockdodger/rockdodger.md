## Notes
Thanks to the [Paul Holt, Robert P Krawczyk & following Contributors](https://bitbucket.org/rpkrawczyk/rockdodger/) for creating this gem and making it open source!

Copyright (c) 2001-2015 Paul Holt <pcholt@gmail.com>
Copyright (c) 2010-2015 Robert P Krawczyk <rpkrawczyk@gmail.com>

## Controls

| Button | Action |
|--|--| 
|DPAD| Move|
|A| Shoot|
|B| Shield|
|Y| Pause|

## Compile

```shell
git clone https://bitbucket.org/rpkrawczyk/rockdodger.git
make
```