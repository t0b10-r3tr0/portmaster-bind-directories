## Notes
Thanks to the [Andy Southgat and Hugh Robinson](https://sdl-asylum.sourceforge.net/) for creating this game and making it available for free!

## Controls

| Button | Action |
|--|--| 
|DPAD| Player 1 Controls|
|B| Jump|
|A| Shoot|
|Y| Resume (r) |
|L1| 1|
|L2| 2|
|R2| 3|

## Compile

```shell
dget -u http://deb.debian.org/debian/pool/main/a/asylum/asylum_0.3.2-3.dsc
cd asylum-0.3.2/
make
```