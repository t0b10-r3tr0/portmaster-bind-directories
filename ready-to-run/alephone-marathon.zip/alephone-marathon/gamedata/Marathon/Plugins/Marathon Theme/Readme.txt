Art assets in this plugin are based on art from the Marathon series, copyright Bungie. Please contact Bungie before using these assets for any commercial purpose, or any purpose not directly connected with the Marathon community.

The Marapfhont typeface was created by Tim Larson. See the readme file within the "resources" directory for information.

The URW Gothic L typefaces were produced by (URW)++. See the readme file within the "resources" directory for information.
