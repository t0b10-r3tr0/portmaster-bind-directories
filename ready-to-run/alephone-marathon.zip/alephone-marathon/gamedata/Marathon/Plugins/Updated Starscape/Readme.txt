The original starscape pattern was downloaded from:
http://webtreats.mysitemyway.com/tileable-classic-nebula-space-patterns/

License and FAQs available at: 
http://mysitemyway.com/etc-readme/

Modifications and packaging by hopper@whpress.com
