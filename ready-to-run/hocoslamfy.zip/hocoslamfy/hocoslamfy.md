## Notes
<br/>

Thanks to [Nebuleon](https://github.com/Nebuleon/hocoslamfy) and other contributors for creating this game and making available for free. Also thanks to Cebion for the packaging for portmaster.
<br/>

