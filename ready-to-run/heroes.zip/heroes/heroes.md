## Notes
Thanks to [Alexandre Duret-Lutz & Therealtech People](https://heroes.sourceforge.net/) for creating this awesome game.

## Controls

| Button | Action |
|--|--| 
|DPAD| Move|
|B| Boost|
|Y| Stop|

## Compile ## 

```bash
git clone https://github.com/Cebion/heroes
cd heroes
./configure
make
```

