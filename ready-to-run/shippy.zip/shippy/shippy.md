## Notes

The Earth is under attack. The only trained pilots, Sora and Fumiko, race to defeat the invaders. The experimental ships are Earth only hope.

Can play in one or two player mode.

Thanks to [Dulsi](https://identicalsoftware.com/) for releasing this game.

[Source code]( https://github.com/dulsi/shippy1984)



## Controls

| Button | Action |
|--|--| 
|UP|Up|
|DOWN|Down|
|LEFT|Left|
|RIGHT|Right|
|X|Fire|
|Y|Fire|


