## Notes
<br/>

Thanks to [omf2097 team](https://github.com/omf2097/openomf) for creating this opensource port.  Also thanks to Cebion for the porting work for portmaster.
<br/>

## Controls
| Button | Action |
|--|--| 
|DPAD|Move|
|A|Punch|
|B|Kick|
|Select|Menu|
|Start|Select Item|