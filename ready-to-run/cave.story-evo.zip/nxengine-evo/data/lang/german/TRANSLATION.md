CAVE STORY - Eine Höhlengeschichte
Deutsche Übersetzung by Reality Dreamers v.1.00
=================================

Übersetzung: Splashman
QC / NXEngine Port: Yaroneko
Playtest Roboter: GhostPhanom, Arandui, Nuss

http://www.reality-dreamers.de/
https://rd.mangadex.com/

-----------------------------------------
Deutsche Übersetzung von Reality Dreamers
-----------------------------------------
Basiert auf der japanischen Vorlage und der englischen Fan-Übersetzung von Aeon Genesis.

Übersetzung: Splashman
QC / NXEngine-evo Port: Yaroneko
Playtest Roboter: GhostPhanom, Arandui, Nuss
Special Thanks: Arandui, PK, Aeon Genesis, iSage, Cave Story Tribute Discord

http://www.reality-dreamers.de/
https://rd.mangadex.com/
https://www.thpatch.net/wiki/Portal:De
https://www.cavestory.org/download/cave-story.php

-----------------------------
Was ist Cave Story überhaupt?
-----------------------------

Cave Story ist ein klassisches Doujin PC Game von 2005 vom Japanischen 1-Mann Team "Studio Pixel".
Es lehnt sich stark an das "Metroidvania"-Gameplay der Metroid und Castlevania Serien an, sprich, ein 2D-Platformer mit einem Karten-basierten Erkundigungsfokus.
Das Freeware Game fand schon in seinen frühen Tagen an großer Beliebtheit, und wurde nach einigen Jahren als Remake für diverse Konsolen und andere Plattformen offiziell von Nicalis verkauft.
Die Originalversion ist und bleibt weiterhin Freeware und darf von der Community für Fan-Zwecke modifiziert werden.

----------------------------------------
Wie kam es überhaupt zu der Übersetzung?
----------------------------------------
Ganz einfach, ich (Splashman) möchte Cave Story meinem 6 Jahre alten Neffen näherbringen, der schon bald lesen lernt.
Doch ich war leider mit der Qualität der bisherigen deutschen Übersetzungen nicht ganz zufrieden,
weshalb ich mich entschloss nach +25 Touhou-Games ein anderes berühmtes Doujin-Game von einem 1-Mann Team anzupacken.

-----------------------
Wer sind wir überhaupt?
-----------------------
Reality Dreamers sind ein kleines deutsches Übersetzungsteam, mit Vorliebe für die Touhou Project Serie.
Neben Spielen übersetzen wir auch Mangas, Bücher und diverse andere Dinge, dabei legen wir immer Wert darauf
die japanische Vorlage für die Übersetzung zu verwenden.

------------------------------------
Wo ist denn überhaupt der Überhaupt?
------------------------------------
Woher soll ich das wissen?