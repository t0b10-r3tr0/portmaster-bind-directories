# Aleph One #

Aleph One is the open source continuation of Bungie's Marathon 2 FPS game
engine. Aleph One plays Marathon, Marathon 2, Marathon Infinity, and 3rd-party
content on a wide array of platforms, with (optional) OpenGL rendering,
Internet play, Lua scripting, and more.

Binary releases and scenario files are available at the Aleph One web site:

<https://alephone.lhowon.org/>

For more information and instructions on compiling from source, check out the
Aleph One wiki:

<https://github.com/Aleph-One-Marathon/alephone/wiki>
