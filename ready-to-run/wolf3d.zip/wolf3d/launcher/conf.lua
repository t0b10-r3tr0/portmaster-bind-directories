function love.conf(t)
    t.window.vsync = 1  -- Enable vertical sync to limit FPS to the monitor's refresh rate
end
