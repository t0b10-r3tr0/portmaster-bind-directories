## Notes
<br/>

Thanks to [Lancer-X/ASCEAI](https://github.com/zear/meritous) and other contributors for creating this game and making available for free. Also thanks to Cebion and Romadu for the packaging for portmaster.
<br/>

