## Notes
Thanks to the [Santiago Ontañón & following Contributors](http://www.braingames.getput.com/stransball2/) for creating this gem and making it open source!

## Controls

| Button | Action |
|--|--| 
|DPAD| Move|
|A| Shoot|
|L1| Info screen|
|R1| Replays|

## Compile

```shell
git clone https://github.com/Cebion/stransball2
cd stransball2/sources
make
```