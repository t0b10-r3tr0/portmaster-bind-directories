  - Rows are:
    - First row: normal
    - Second row: when shooting
  - Colors are:
    - Red (0 hue): skin
    - Green (120 hue): hair
    - Any other shade: as is (recommend R, G, and B between 5 and 250)
  - Head will be rendered centered, but the base of the head when looking up
    should appear 3 pixels below the center
    - Note: head height must be even otherwise they will be offset by 1px (this is a bug)
