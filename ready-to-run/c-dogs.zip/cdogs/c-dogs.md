## Notes
<br/>

Thanks to [cxong](https://github.com/cxong/cdogs-sdl) for this SDL build of the game that makes this possible.
<br/>

