## Notes
<br/>

Thanks to [Stephen Sweeney](https://github.com/perpendicular-dimensions/blobwars) and other contributors for creating this game and making available for free. Also thanks to Cebion for the packaging for portmaster.
<br/>

## Compile

```bash
git clone https://git.code.sf.net/p/blobwars/code blobwars-code
make CFLAGS="-Wno-error=format-truncation"
```