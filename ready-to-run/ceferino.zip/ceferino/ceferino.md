## Notes
Thanks to the [Hugo Ruscitti, Walter Velazquez](http://www.losersjuegos.com.ar/) for creating this game and making it available for free!

## Controls

| Button | Action |
|--|--| 
|DPAD| Move|
|Start| Continue|
|B| Fire|
|Y| Sweep|


## Compile

```shell
git clone git@github.com:Cebion/ceferino_pm.git
./configure
make
```