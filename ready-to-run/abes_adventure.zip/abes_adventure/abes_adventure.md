## Notes
<br/>

Thanks to [Gabor Torok/Pedro Izecksohn](https://abe.sourceforge.net/) and other contributors for creating this game and making available for free. Also thanks to Cebion for the packaging for portmaster.
<br/>

## Compile

```shell
wget https://sourceforge.net/projects/abe/files/abe/abe-1.1/abe-1.1.tar.gz
./autogen.sh
./configure
make -j8
```