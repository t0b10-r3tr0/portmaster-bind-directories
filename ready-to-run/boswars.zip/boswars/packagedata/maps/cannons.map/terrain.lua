-- terrain
patch("te5", 0, 0)
patch("te5", 16, 0)
patch("te5", 0, 16)
patch("te5", 16, 16)

