patchType("plain2", "patches/plain2.png", 2, 2, {
 0x0013, 0x0013,
 0x0013, 0x0013,
}, "Others")
