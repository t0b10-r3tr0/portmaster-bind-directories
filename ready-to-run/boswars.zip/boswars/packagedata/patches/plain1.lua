patchType("plain1", "patches/plain1.png", 1, 1, {
 0x0013,
}, "Others")
