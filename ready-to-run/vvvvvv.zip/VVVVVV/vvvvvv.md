## Notes
<br/>

Thanks to [Terry Cavanagh](https://github.com/TerryCavanagh/VVVVVV) and other authors and contributors for the creation and continued updates of this game.
<br/>

