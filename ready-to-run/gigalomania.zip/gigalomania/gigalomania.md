## Notes
<br/>

Thanks to [Mark Harman](https://gigalomania.sourceforge.net/) and other contributors for creating this game and making available for free. Also thanks to Cebion for the packaging for portmaster.
<br/>

