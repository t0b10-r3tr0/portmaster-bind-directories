This dir (\_save_palette) will contain the palette-setting scripts created with 

[>MISC]-->[Save Palette as Script] (fil_db_SavePalette.lua)

The created scripts will have the name(s): pal_zz_SetPalette#.lua (where # is the number 0..)
