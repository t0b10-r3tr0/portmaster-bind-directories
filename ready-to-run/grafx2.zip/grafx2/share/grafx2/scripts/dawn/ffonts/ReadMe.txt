\ffonts is the directory for additional fonts for use with the text-library (db_text.lua)
