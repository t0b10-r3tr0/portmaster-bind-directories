These are 'KEY'-scripts which are meant to be assigned to keys and used with the mouse-pointer:

bru_db_ColorAreaGrab.lua	-- Grabs a brush from the floodfilled area of color under the mouse-pointer
bru_db_MagicBrushGrab.lua	-- Grabs a brush of the image under the mouse-pointer (that is not bg-col)
bru_db_MagicBrushGrab_remove.lua-- Same as MagicBrushGrab, but removes the grabbed gfx from the image (Sprite move)
col_db_FindColorBRIGHT92.lua	-- Selects the next brighter color in the palette, from the current pen-color
col_db_FindColorDark92.lua	-- Selects the next darker color in the palette, from the current pen-color
pic_db_checkDitherPenColor.lua	-- Dithers all image instances of the color under the mouse-pointer with current pen-color
pic_db_floodDither.lua		-- Dither floodfills the area/color under the mouse-pointer with current pen-color
pic_db_floodInline.lua		-- "Outlines" the inside of the area/color under the mouse-pointer using current pen-color


Richard 'DawnBringer' Fhager
dawnbringer@hem.utfors.se
or
dawnbringer@bahnhof.se



