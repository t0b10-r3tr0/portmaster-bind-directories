\gradients

These are normal scripts, mostly for preset 256 color gradients/ramps/palettes.

in \pics are results of gradients that have been analyzed with pic_db_GradientAnalyze.lua