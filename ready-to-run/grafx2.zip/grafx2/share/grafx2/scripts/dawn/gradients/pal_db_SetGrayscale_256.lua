-- Plain Grayscale 256 


for n = 0, 255, 1 do
 setcolor(n,n,n,n)
end

