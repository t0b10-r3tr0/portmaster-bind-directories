Landscaper:

This is a script/program that generates isometric lightsourced Perlin-noise (procedural landscapes).

It can be launched via the ToolBox menu from [>SCENE] --> [>CLOUDS & NOISE] --> [# LANDSCAPER]

For a quick demonstration of the program: 
Select [:Scenes:] --> [{Preset Scenes}] --> [Titan Sunrise] (or any of the other scenes available)
Now press [BACK] to return to the main menu, and hit [RENDER >>]