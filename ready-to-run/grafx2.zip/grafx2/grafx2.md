## Notes
Thanks to the [Grafx2 Team](http://grafx2.chez.com/) for creating this tool and making it available for free!

## Controls

The following instructions are for a right-facing character. 

| Button | Action |
|--|--| 
|DPAD| Mouse |
|A| Left Mouse |
|B| Right Mouse |
|X| Slow Mouse |
|L1| CTRL|

## Compile ## 

```bash
git clone https://gitlab.com/GrafX2/grafX2
cd grafX2/
make API=sdl2
```