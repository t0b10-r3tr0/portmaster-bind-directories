## Notes

Copy your Shovel Knight Treasure Trove for Linux folder to the ports/shovelknight/gamedata folder.  You should have ports/shovelknight/gamedata/shovelknight folder structure with additional subfolders such as 32, 64, and data within ports/shovelknight/gamedata/shovelknight.  Once done, just run Shovel Knight.sh.

Thanks to ptitSeb for box86 (https://github.com/ptitSeb/box86)
Thanks to JohnnyonFlame for gl4es and the necessary packaging to allow this game to run on supported linux distros. (https://github.com/JohnnyonFlame/gl4es/tree/sk_hacks)
You can donate towards JohnnyonFlame's work [here](https://ko-fi.com/johnnyonflame)





