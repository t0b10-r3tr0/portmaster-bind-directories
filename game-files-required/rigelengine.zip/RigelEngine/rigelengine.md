## Notes
<br/>

Thanks to [Lethal Guitar](https://github.com/lethal-guitar/RigelEngine) for the source port of this game.  Also thanks to romadu for the porting work for portmaster.
<br/>

