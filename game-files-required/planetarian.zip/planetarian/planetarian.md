## Installation
You need a copy of [Planetarian: The Reverie of a Little Planet](https://store.steampowered.com/app/316720). Install the `rlvm` runtime and copy the game files to `ports/planetarian/gamedata`.

Planetarian HD does _not_ work!

## Default Gameplay Controls
| Button | Action |
|--|--|
|Select|Back|
|Start|Start|
|A|Accept|
|B|Cancel / Open Menu|
|L1|Scroll back dialog|
|R1|Scroll forward dialog|
|L2|Fast forward dialog|
|D-Pad / Sticks|Move cursor|

## Thanks
Kloptops - Original port  
eglaysher - Rlvm original  
a1batross - Rlvm SDL2 fork  
Testers and Devs from the PortMaster Discord  
