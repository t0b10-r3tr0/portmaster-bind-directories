## Notes
<br/>

Thanks to [Eugene C.](https://github.com/ec-/Quake3e) for developing this updated engine and [brooksytech](https://github.com/brooksytech/Quake3e) for the porting work for portmaster.
<br/>

