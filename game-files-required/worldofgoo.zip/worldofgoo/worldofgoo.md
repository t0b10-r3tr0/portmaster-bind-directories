## Notes

Thanks to the wonderful developers of 2D Boy for creating such a wonderful game.
https://www.gog.com/en/game/world_of_goo

GOG Files are compatible.
Steam Game files may work

## Controls

| Button | Action |
|--|--|
| Dpad | Move |
| A | Left Click |
| X | Slow Mouse |