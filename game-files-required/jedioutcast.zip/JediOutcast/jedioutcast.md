## Notes
<br/>

Thanks to [JACoders](https://github.com/JACoders/OpenJK) for the opensource engine.  Also thanks to [brooksytech](https://github.com/brooksytech/OpenJK-RG552) for the porting and packaging for portmaster.
<br/>

