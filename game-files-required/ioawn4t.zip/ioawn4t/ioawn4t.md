## Notes

If On A Winter's Night, Four Travelers is available to download for free on [Itch](https://laurahunt.itch.io/if-on-a-winters-night-four-travelers) and [Steam](https://store.steampowered.com/app/1603980/If_On_A_Winters_Night_Four_Travelers/). Huge thanks to [Dead Idle Games](https://twitter.com/deadidlegames) for making this amazing game!

A thanks goes out to [JanTrueno](https://github.com/JanTrueno) for bringing over [Adventure Game Studio](https://www.adventuregamestudio.co.uk/) to PortMaster and doing the porting work. 

Dont forget to read the message at start-up!

## Controls

| Button | Action |
|--|--| 
|D-Pad/L-Stick|Cursor Movement|
|X/Y|Slow Cursor|
|A|Left Click|
|B|Right Click|
|Start|Menu|
|Back Buttons|Number|


