## Notes

The Steam version seems to work best as it's patched for Linux use already.

Thanks to [Donny Springer, Zack Middleton, James Canete and other contributors](https://github.com/iortcw/iortcw) for this engine. 



