## Notes

Original version by:
https://bootdiskrevolution.com

Portmaster Version: 	
https://github.com/JohnnyonFlame/FNAPatches
	
## Description
Bleed 2 is a relentless arcade action game featuring air-dodging,
bullet-reflecting, and tons of bosses.

Wryn is the world's greatest (and only remaining) hero. Help her battle an
invading force of villains and live up to her title as the Greatest Hero of
All Time!

Featuring an original soundtrack by Jukio Kallio and sound design by
Joonas Turner!

## Controls

| Button | Action |
|--|--|
| Left-Analog | Movement |
| Right-Analog | Fire, Melee/Parry |
| R2 | Jump/Dodge |
| L2 | Bullet Time |
| R1 | Alt. Fire |
| L1 | Previous Weapon |
| X | Next Weapon |
| A | Taunt |
