## Notes

Thanks to [Castle Pixel](http://castlepixel.com/) for creating this amazing game! You can buy the game here: [Steam](https://store.steampowered.com/app/1747830/Blossom_Tales_II_The_Minotaur_Prince/)

A thanks also goes out to [JohnnyOnFlame](https://ko-fi.com/johnnyonflame) for bringing over the Mono framework to PortMaster.

Note: This game requires an RK3566 or above. In the last fight, theres one moment where the game drops in framerate.

## Controls

| Button | Action |
|--|--| 
|D-Pad/L-Stick|Movement|
|A|Interact|
|B|Item 1|
|X|Item 2|
|Y|Roll|
|Select|Map|
|Start|Menu|


