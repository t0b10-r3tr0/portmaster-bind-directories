## Notes

Huge thanks to [Hopoo Games](https://hopoogames.com/) for creating this amazing game. Check out the game on [Steam](https://store.steampowered.com/app/248820/Risk_of_Rain_2013/). A Huge thanks to JohnnyOnFlame for Gmloader-Next.

## Controls

| Button | Action |
|--|--| 
|D-pad|Move|
|A|Jump|
|B|Use Item|
|X|Enter|
|Y|Swap Item|
|R1/R2/L1/L2|Abilities|
|Start|Menu|


