## Notes

Thanks to Last Dimension Team for creating this game.
https://store.steampowered.com/app/332610/Mystik_Belle/

## Default Controls

| Button | Action |
|--|--|
| D-PAD / JOYSTICK  | Move          |
| START             | Pause         |
| A                 | Accept / Jump |
| B                 | Menu          |
| X                 | Fire          |
| Y                 | Action        |
| L2                | Dash          |