# Haque - PortMaster xDelta
===========================
This xdelta modifies the following:

- 256x256 texture page size
- Clamp a variable in draw_console script to prevent invalid array access