## Notes

A thanks goes out to the following:
- [Doinksoft](https://store.steampowered.com/developer/DevolverDigital) for making this amazing game, check it out on [Steam](https://store.steampowered.com/app/916730/Gato_Roboto/) or [GOG](https://www.gog.com/en/game/gato_roboto/).
- Jantrueno for doing the porting work.
- JohnnyOnFlame for gmloader-next.
- Fraxinux88 for GOG compatibility.
- Kotzebuedog for the GMKtool.
 
Patching process for this one is a couple minutes! Game keeps aspect, 16:9.

## Controls

| Button | Action |
|--|--| 
|D-pad/L-stick|Movement|
|A|Fire Rocket|
|B|Jump|
|X|Exit Mech|
|Y|Fire Pistol|
|L|Phase|
|Start|Pause|


