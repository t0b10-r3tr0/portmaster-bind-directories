## Notes
<br/>

Thanks to the [FNA-XNA](https://github.com/FNA-XNA/FNA) project for the runtime that's used to make this possible.
Thanks to JohnnyonFlame for the FNA fork to run FNA games on these devices.
Thanks to jtothebell for the port work that makes this possible.
You can sponsor FNA-XNA's work [here](https://github.com/sponsors/flibitijibibo)
You can donate towards JohnnyonFlame's work [here](https://ko-fi.com/johnnyonflame)
You can sponsor jtothebell's work [here](https://github.com/sponsors/jtothebell)
<br/>

