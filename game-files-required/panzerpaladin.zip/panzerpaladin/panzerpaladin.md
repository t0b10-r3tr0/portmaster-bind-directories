## Notes

A game by Tribute Games Inc.:
https://panzerpaladin.com/

Portmaster Version:
https://github.com/JohnnyonFlame/FNAPatches

## Controls

| Button | Action |
|--|--| 
|DPAD|Move|
|A|Jump|
|X|Attack|
|Y|Throw|
|B|Backdash|
|Start|Menu|
|RB/LB|Select Weapon|
|RT+LT|Break Weapon|
|Select|Eject|
