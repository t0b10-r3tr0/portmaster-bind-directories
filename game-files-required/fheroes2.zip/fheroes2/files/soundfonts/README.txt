This directory contains SoundFont files for MIDI synthesizer.
======

fheroes2.sf3 - SoundFont for MIDI synthesizer based on the GeneralUser GS
               v1.471 by S. Christian Collins:
               http://www.schristiancollins.com/generaluser.php
               All samples, instruments and presets that were not used in
               the MIDI tracks of the original game were removed, the rest
               was converted to SF3 format using Polyphone 2.3.1.
