## Notes

Original version by:
https://www.anodynegame.com/

Remake/FNA versions by:  
https://github.com/PixieCatSupreme/AnodyneSharp  
https://github.com/flibitijibibo/AnodyneFNA

Portmaster Version: 	
https://github.com/JohnnyonFlame/FNAPatches

## Controls

| Button | Action |
|--|--| 
|DPAD|Move|
|B|Jump|
|A|Attack|
|Start|Menu|
|RT/LT| Select Item|


