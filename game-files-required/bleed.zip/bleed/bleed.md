## Notes

Original version by:
https://bootdiskrevolution.com

Portmaster Version: 	
https://github.com/JohnnyonFlame/FNAPatches
	
## Description
Wryn is a girl with a big arsenal and big dreams -- she wants to be the ultimate
videogame hero! Help her take down the Greatest Heroes of All Time in an
action-packed bid to claim the title for herself and show the world what a true
hero looks like!

Bleed is an action-platformer focused on stylish, acrobatic dodging and fluid,
challenging gameplay. There's no filler -- just you and your skills against
seven levels of enemies, obstacles, breakneck set-pieces and inventive bosses!

## Controls

| Button | Action |
|--|--|
| Left-Analog | Movement |
| Right-Analog | Fire |
| R2 | Jump/Dodge |
| L2 | Bullet Time |
| R1 | Next Weapon |
| L1 | Previous Weapon |
| R3 | Alt. Fire |

