## Notes

Big thanks to [Maddy Makes Games](https://www.mattmakesgames.com/) for creating this amazing game! You can purchase the game here: [GOG](https://www.gog.com/game/towerfall_ascension) or [Itch](https://maddymakesgamesinc.itch.io/towerfall)

A thanks also goes out to [JohnnyOnFlame](https://ko-fi.com/johnnyonflame) for bringing over the Mono framework to PortMaster. 

## Controls

| Button | Action |
|--|--| 
|D-Pad/L-Stick|Move/Aim|
|A|Alt Shoot|
|B|Jump|
|X|Arrow Toggle|
|L2/R2|Dodge/Catch|
|Start|Pause|


